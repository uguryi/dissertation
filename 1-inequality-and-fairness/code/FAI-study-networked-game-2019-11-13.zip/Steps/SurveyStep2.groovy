surveyStep2 = stepFactory.createStep()

surveyStep2.run = {
  
  println "surveyStep2.run"
  
  version_ee = ["""You start the community game with a score that is the average of 
    			   the scores of all players in the word game. This score could 
                   be lower than, equal to, or higher than your actual score from 
                   the word game depending on how your personal performance 
                   compares to how well the other players did in the game. For 
                   example, even if you performed well in the word game, if 
                   other players did not perform as well as you did, your score 
                   will unfortunately go down. Similarly, even if you performed 
                   poorly in the word game, if other players performed better 
                   than you did on average, then your score will go up.""", "ee"]
  version_eu = ["""You start the community game with your score from the word game. 
                   Other players similarly start this game with whatever score 
                   they were able to achieve in the word game. In other words, 
                   those who performed well in the word game start the community 
                   game with a higher score than others who did not perform as 
                   well.""", "eu"]
  version_re = ["""We disregard your score from the word game. Instead, You start 
    			   the community game with a score that we randomly assign to you. 
                   All participants in your group are assigned the exact same 
                   score.""", "re"]
  version_ru = ["""We disregard your score from the word game. Instead, you start 
    			   the community game with a score that we randomly assign to you. 
                   This score could be lower than, equal to, or higher than your 
                   actual score from the word game. In other words, even if you 
                   performed well in the word game, you could unfortunately still 
                   get a score that is much lower. Similarly, even if you performed 
                   poorly in the word game, you could still get a score that is 
                   much higher. It is highly likely that different players will be 
                   assigned different random scores.""", "ru"]
  
  if (version1 == 'ee') {
    first_version = version_ee
  } else if (version1 == 'eu') {
    first_version = version_eu
  } else if (version1 == 're') {
    first_version = version_re
  } else {
    first_version = version_ru
  }
  if (version2 == 'ee') {
    second_version = version_ee
  } else if (version2 == 'eu') {
    second_version = version_eu
  } else if (version2 == 're') {
    second_version = version_re
  } else {
    second_version = version_ru
  }
    
  g.V.filter{it.active}.each { player->
    
    if (metaCount == 0) {
      player.text = c.get("Finished", player.private.score)
      a.addEvent("Score2",["pid":player.id,
                           "score2":player.private.score])
    } else {
      player.text = c.get("Finished-ThirdGame", player.private.score)
      a.addEvent("Score3",["pid":player.id,
                           "score3":player.private.score])
    }
    
    a.add(player, [name: "Next", result: {
      player.text = c.get("SurveyStep2")
    }])
    
    if (metaCount == 0) {
      
      a.add(player,
      [name: "Submit",
      custom: """
      <p>Do you think that most of your neighbors tried to take advantage of you 
      	 when they got the chance, or did they try to be fair?</p>
      <p><strong>Most of them tried to take advantage of me.</strong></p>
      <div>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="1" required> 
        <label for="1"> 1</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="2" required> 
        <label for="2"> 2</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="3" required> 
        <label for="3"> 3</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="4" required> 
        <label for="4"> 4</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="5" required> 
        <label for="5"> 5</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="6" required> 
        <label for="6"> 6</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="7" required> 
        <label for="7"> 7</label><br>
      </div>
      <p><strong>Most of them tried to be fair.</strong></p>
      <p><hr></p>
      """.toString(),
      result: { params->
        a.addEvent("TrustScore2", ["pid": player.id,
                                   "trust_score2": params['radio2']])
        player.text += "<p>Please wait for the other players to make their choices.</p>"
        player.text += "<p>While waiting, please stay on this page as you may be dropped for being idle if you don't make your next move within <strong>20 seconds</strong> when it appears.</p>"
      }])
    
    } else {
        
      a.add(player,
      [name: "Submit",
      custom: """
      <p>Do you think that most of your neighbors tried to take advantage of you 
      	 when they got the chance, or did they try to be fair?</p>
      <p><strong>Most of them tried to take advantage of me.</strong></p>
      <div>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="1" required> 
        <label for="1"> 1</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="2" required> 
        <label for="2"> 2</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="3" required> 
        <label for="3"> 3</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="4" required> 
        <label for="4"> 4</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="5" required> 
        <label for="5"> 5</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="6" required> 
        <label for="6"> 6</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="7" required> 
        <label for="7"> 7</label><br>
      </div>
      <p><strong>Most of them tried to be fair.</strong></p>
      <p><hr></p>
      """.toString(),
      result: { params->
        a.addEvent("TrustScore3", ["pid": player.id,
                                   "trust_score3": params['radio2']])
        player.text += "<p>Please wait for the other players to make their choices.</p>"
        player.text += "<p>While waiting, please stay on this page as you may be dropped for being idle if you don't make your next move within <strong>20 seconds</strong> when it appears.</p>"
      }])
      
    }
    
  }
  
}

surveyStep2.done = {
  
  println "surveyStep2.done"
  
  if (metaCount == 0) {
    curRound = 0
    metaCount++
  	surveyToCoopStep.start()
  } else {
    surveyStepEnd.start()
  }
  
}
