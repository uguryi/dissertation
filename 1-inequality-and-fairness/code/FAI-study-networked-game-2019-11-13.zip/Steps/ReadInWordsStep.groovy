readInWordsStep = stepFactory.createStep()

readInWordsStep.run = {
  
	println "readInWordsStep.run"
  
  	a.setDropPlayers(true)
  
    a.setIdleTime(12)
  
    if (curRound == 0) {
      
      captchas = new File('./' + wordListNo.toString() + '-captchas-100-3-demo.txt')
  	  answers = new File('./' + wordListNo.toString() + '-answers-100-3-demo.txt')
      
    } else {
      
      captchas = new File('./' + wordListNo.toString() + '-captchas-100-3-real.txt')
  	  answers = new File('./' + wordListNo.toString() + '-answers-100-3-real.txt')
      
      g.V.filter{it.active}.each { player->
        player.private.score = initScore
        player.private.words = []
        player.score = initScore
        player.text = c.get("RealFirstGame") + "<p><strong>Click 'Begin' to join the game.</strong></p>"
  	    a.add(player, [name: "Begin", result: {
    	  player.text = c.get("RealFirstGame") + "<p><strong>Thank you, the game will begin in a moment.</strong></p>"
        }])
      }
      
    }
  
    def clines = captchas.readLines()
  	def alines = answers.readLines()
  
  	lst_of_captchas = []
  	lst_of_answers = []
  
    clines.each { String line ->
      lst_of_captchas += [line]
    }
  
  	alines.each { String line ->
      lst_of_answers += [line]
    }
  
	indices = []
  
	(0..lst_of_captchas.size()-1).each{
	  indices += [it]
	}
}

readInWordsStep.done = {
  
	println "readInWordsStep.done"
    surveyStep.start()
  
}
