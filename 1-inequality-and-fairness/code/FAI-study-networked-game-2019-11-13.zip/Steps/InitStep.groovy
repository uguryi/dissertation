curRound = 0
secondGameDemoCounter = 0
metaCount = 0

initStep = stepFactory.createStep()

initStep.run = {
  
  println "initStep.run: ${curRound}"
  
  g.V.filter{it.active}.each { player-> 
    if (player.private.screenAnswer == "") {
      player.active = false
  	  player.dropped = true
  	  a.remove(player.id)
      countP = countP - 1
    }
  }
  
  if (countP < minP) {
    g.V.filter{it.active}.each { player-> 
      player.active = false 
      a.remove(player.id)
      player.text = "<h2>Thank you for reading the tutorial.</h2>"
      player.text += "<p>Unfortunately we don't have enough players to begin the game at this time.</p>"
      player.text += "<p>You can submit the assignment below.</p>"
      player.text += "<p>If you are interested in playing the game, please check back again soon.</p>"
      player.text += g.getSubmitForm(player, 0)
    }
  } else if (countP > maxP) {
    g.V.filter{it.active}.shuffle.each { player-> 
      if (countP > maxP) {
        player.active = false 
        a.remove(player.id)
        player.text = "<h2>Thank you for reading the tutorial.</h2>"
        player.text += "<p>Unfortunately too many people showed interest in the game at this time.</p>"
      	player.text += "<p>As a result, we had to randomly select a smaller subset of players to begin the game.</p>"
      	player.text += "<p>You can submit the assignment below.</p>"
        player.text += "<p>If you are interested in playing the game, please check back again soon.</p>"
      	player.text += g.getSubmitForm(player, 0)
      }
      countP = countP - 1
    }
  }
  
  a.setDropPlayers(true)
  
  a.setIdleTime(20)
  
  if (version1 == 'ee') {
    a.addEvent("GameParameters1", ["earned1": 1, "equal1": 1])
  } else if (version1 == 'eu') {
    a.addEvent("GameParameters1", ["earned1": 1, "equal1": 0])
  } else if (version1 == 're') {
    a.addEvent("GameParameters1", ["earned1": 0, "equal1": 1])
  } else {
    a.addEvent("GameParameters1", ["earned1": 0, "equal1": 0])
  }

  g.random(p)
  
  g.V.each { player-> 
    if (player.active == false) {
      player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
    }
  }
  
  g.V.filter{it.active}.each { player-> 
    player.neighbors.each { n->
      player.private.original_neighbors += [n]
    }
  }

  g.V.filter{it.active}.each { player->
    player.text = c.get("PleaseWait") + "<p><strong>Click 'Begin Demo Run' to join the demo run.</strong></p>"
    a.add(player, [name: "Begin Demo Run", result: {
      player.text = c.get("PleaseWait") + "<p><strong>Thank you, the demo run will begin in a moment.</strong></p>"
    }])
  }
  
}

initStep.done = {
  
  println "initStep.done: ${curRound}"
  readInWordsStep.start()
  
}
