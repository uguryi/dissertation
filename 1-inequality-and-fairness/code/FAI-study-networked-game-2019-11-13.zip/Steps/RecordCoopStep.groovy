recordCoopStep = stepFactory.createStep()

recordCoopStep.run = {
  
  println "recordCoopStep.run"
  
  g.V.filter{it.active}.each { player->
    
    def coopChoiceData = ["version":metaCount+1,
                          "pid":player.id,
                          "round":curRound, 
                          "coopChoice":player.private.cooperation,
                          "score":player.private.score]
    
    lst_current_neighbors = []
    player.neighbors.each { n->
      lst_current_neighbors += [n]
    }
    
    if (lst_current_neighbors != []) {
      player.neighbors.eachWithIndex { n, i->
        text = player.id + "_" + (metaCount+1) +  "_" + curRound + "_"
        coopChoiceData[text + "neighbor_" + i] = n.id 
      }
    } else {
      text = player.id + "_" + (metaCount+1) +  "_" + curRound + "_"
      coopChoiceData[text + "neighbor_0"] = ""
    }

    a.addEvent("CoopChoice", coopChoiceData)
    
  }
    
}

recordCoopStep.done = {
  
	println "recordCoopStep.done"
    resultsStep.start()
  
}
