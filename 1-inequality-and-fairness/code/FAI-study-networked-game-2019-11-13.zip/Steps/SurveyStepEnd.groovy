surveyStepEnd = stepFactory.createStep()

surveyStepEnd.run = {
  
  println "surveyStepEnd.run"
  
  a.setIdleTime(40)
  
  version_ee = ["""You start the community game with a score that is the average of 
    			   the scores of all players in the word game. This score could 
                   be lower than, equal to, or higher than your actual score from 
                   the word game depending on how your personal performance 
                   compares to how well the other players did in the game. For 
                   example, even if you performed well in the word game, if 
                   other players did not perform as well as you did, your score 
                   will unfortunately go down. Similarly, even if you performed 
                   poorly in the word game, if other players performed better 
                   than you did on average, then your score will go up.""", "ee"]
  version_eu = ["""You start the community game with your score from the word game. 
                   Other players similarly start this game with whatever score 
                   they were able to achieve in the word game. In other words, 
                   those who performed well in the word game start the community 
                   game with a higher score than others who did not perform as 
                   well.""", "eu"]
  version_re = ["""We disregard your score from the word game. Instead, You start 
    			   the community game with a score that we randomly assign to you. 
                   All participants in your group are assigned the exact same 
                   score.""", "re"]
  version_ru = ["""We disregard your score from the word game. Instead, you start 
    			   the community game with a score that we randomly assign to you. 
                   This score could be lower than, equal to, or higher than your 
                   actual score from the word game. In other words, even if you 
                   performed well in the word game, you could unfortunately still 
                   get a score that is much lower. Similarly, even if you performed 
                   poorly in the word game, you could still get a score that is 
                   much higher. It is highly likely that different players will be 
                   assigned different random scores.""", "ru"]
  
  if (version1 == 'ee') {
    first_version = version_ee
  } else if (version1 == 'eu') {
    first_version = version_eu
  } else if (version1 == 're') {
    first_version = version_re
  } else {
    first_version = version_ru
  }
  if (version2 == 'ee') {
    second_version = version_ee
  } else if (version2 == 'eu') {
    second_version = version_eu
  } else if (version2 == 're') {
    second_version = version_re
  } else {
    second_version = version_ru
  }
  
  if (version1 != version2) {
    
    g.V.filter{it.active}.each { player->
      
      player.private.bonus = ((player.private.version1_score + player.private.score)/6000).toDouble().round(2)
      if (player.private.bonus < 0) {
        player.private.bonus = 0
      }
      if (player.private.bonus > 1.25) {
        player.private.bonus = 1.25
      }
      player.private.bonus = (2.9 + player.private.bonus).toDouble().round(2)
      
      player.text = c.get("SurveyStep3-Alt")
      
      player.text += "<p><strong>The rules for the first version of the game:</strong></p>"
      player.text += "<p>${first_version[0]}</p>"
      player.text += "<p><strong>The rules for the second version of the game:</strong></p>"
      player.text += "<p>${second_version[0]}</p>"
    
	  first = """ 
    		  <input type="radio" class="param" name="radio" ng-model="radio" value="first" required> 
      		  <label for="first"> first version </label><br>
    		  """
	  second = """ 
    		  <input type="radio" class="param" name="radio" ng-model="radio" value="second" required> 
      		  <label for="second"> second version </label><br>
    		  """
      lst_strings = [first, second]
    
      first2 = """ 
    		  <input type="radio" class="param" name="radio2" ng-model="radio2" value="first" required> 
      		  <label for="first"> first version </label><br>
    		  """
	  second2 = """ 
    		  <input type="radio" class="param" name="radio2" ng-model="radio2" value="second" required> 
      		  <label for="second"> second version </label><br>
    		  """
      lst_strings2 = [first2, second2]
    
      a.add(player,
      [name: "Submit",
      custom: """
      <p><strong>Please tell us which version seems MORE FAIR to you.</strong></p>
      <div>
        ${lst_strings[0]}
        ${lst_strings[1]}
      </div>
      <p><hr></p>
      <p><strong>If you had the chance to play this game one more time, which version would you like to play?</strong></p>
      <div>
        ${lst_strings2[0]}
        ${lst_strings2[1]}
      </div>
      <p><hr></p>
      """.toString(),
      result: { params->
        a.addEvent("Relative", ["pid": player.id,
                                "first_vs_second": params['radio'],
                                "prefer": params['radio2'],
                                "first_version": version1,
                                "second_version": version2])
        player.text = c.get("SurveyStep2")}])
        
      a.add(player,
      [name: "Submit",
      custom: """
      <p>
         Recall the many choices you had to make whether to 
         <strong>take action A (and contribute points to your neighbors)</strong> 
         or 
         <strong>take action B (and NOT contribute points to your neighbors)</strong> during the game.
      </p>
      <p><strong>
         Which of the following factors were most influential in making you choose action A 
         (and contribute points to your neighbors)? You can check one or more boxes. 
      </strong></p>
      <div>
         <input type="checkbox" class="param" name="checkboxes" ng-model="altruism" value="altruism" 
         ng-required="!encourage && !choseA && !choseB && !equal && !more && !less && !fair && !notfair && !other">
         <label for="altruism">I wanted other players to increase their scores.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="encourage" value="encourage" 
         ng-required="!altruism && !choseA && !choseB && !equal && !more && !less && !fair && !notfair && !other">
         <label for="encourage">I wanted to encourage other players to choose A too.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="choseA" value="choseA" 
         ng-required="!altruism && !encourage && !choseB && !equal && !more && !less && !fair && !notfair && !other">
         <label for="choseA">Most of my neighbors chose A in the previous round.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="choseB" value="choseB" 
         ng-required="!altruism && !encourage && !choseA && !equal && !more && !less && !fair && !notfair && !other">
         <label for="choseB">Most of my neighbors chose B in the previous round.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="equal" value="equal" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !more && !less && !fair && !notfair && !other">
         <label for="equal">Most of my neighbors had similar scores compared to me.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="more" value="more" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !less && !fair && !notfair && !other">
         <label for="more">Most of my neighbors had higher scores compared to me.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="less" value="less" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !more && !fair && !notfair  && !other">
         <label for="less">Most of my neighbors had lower scores compared to me.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="fair" value="fair" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !more && !less && !notfair && !other">
         <label for="fair">I found the rule of initial score allocation to be fair.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="notfair" value="notfair" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !more && !less && !fair && !other">
         <label for="notfair">I didn't find the rule of initial score allocation to be fair.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="other" value="other" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !more && !less && !fair && !notfair">
         <label for="other">Other factor not listed here (type your reason below).</label><br>

         <input ng-if="other" type="text" name="othertext" class="param" ng-model="othertext" required>
      </div>
      <p><hr></p>
      """.toString(),
      result: { params->
        a.addEvent("WhyCoop", ["pid": player.id,
                               "why_coop": params['checkboxes'],
                               "why_coop_other": params['othertext']])
        player.text = c.get("SurveyStep2")}])

      a.add(player,
      [name: "Submit",
      custom: """
      <p>How many other HITs have you participated in that required you to interact with other players like this HIT?</p>
      <div>
        <input type="number" class="param" min="0" max="1000000" name="numeric1" ng-model="numeric1" required>
      </div>
      <p><hr></p>
      <p>How old are you?</p>
      <div>
        <input type="number" class="param" min="0" max="200" name="numeric2" ng-model="numeric2" required>
      </div>
      <p><hr></p>
      <p>What gender do you identify with?</p>
      <div>
        <input type="radio" class="param" name="radio1" ng-model="radio1" value="male" required> 
        <label for="male"> Male</label><br>
        <input type="radio" class="param" name="radio1" ng-model="radio1" value="female" required> 
        <label for="female"> Female</label><br>
        <input type="radio" class="param" name="radio1" ng-model="radio1" value="other" required> 
        <label for="other"> Other</label><br>
      </div>
      <p><hr></p>
      <p>What race/ethnicity do you identify with?</p>
      <div>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="white" required> 
        <label for="white"> White</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="black" required> 
        <label for="black"> Black</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="hispanic" required> 
        <label for="hispanic"> Hispanic</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="asian" required> 
        <label for="asian"> Asian</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="other" required> 
        <label for="other"> Other</label><br>
      </div>
      <p><hr></p>
      <p>What is your level of education?</p>
      <div>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="less_than_hs" required> 
        <label for="less_than_hs"> Less than high school diploma</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="hs" required> 
        <label for="hs"> High school diploma or equivalent</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="some_college" required> 
        <label for="some_college"> Some college</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="college_degree" required> 
        <label for="college_degree"> College degree</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="graduate_degree" required> 
        <label for="graduate_degree"> Graduate degree</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="other" required> 
        <label for="other"> Other</label><br>
      </div>
      <p><hr></p>
      <p>What is your yearly income in US dollars?</p>
      <div>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="less_than_20k" required> 
        <label for="less_than_20k"> Less than \$20,000</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="20k_to_40k" required> 
        <label for="20k_to_40k"> \$20,000 to \$39,999</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="40k_to_60k" required> 
        <label for="40k_to_60k"> \$40,000 to \$59,999</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="60k_to_80k" required> 
        <label for="60k_to_80k"> \$60,000 to \$79,999</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="80k_to_100k" required> 
        <label for="80k_to_100k"> \$80,000 to \$99,999</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="more_than_100k" required> 
        <label for="more_than_100k"> More than \$100,000</label><br>
      </div>
      <p><hr></p>
      <p>Which of the following best describes your political orientation?</p>
      <div>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="very_liberal" required> 
        <label for="very_liberal"> Very liberal</label><br>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="liberal" required> 
        <label for="liberal"> Liberal</label><br>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="middle" required> 
        <label for="middle"> Middle of the road</label><br>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="conservative" required> 
        <label for="conservative"> Conservative</label><br>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="very_conservative" required> 
        <label for="very_conservative"> Very conservative</label><br>
      </div>
      <p><hr></p>
      <p>Are you located in the U.S.?</p>
      <div>
        <input type="radio" class="param" name="radio6" ng-model="radio6" value="yes" required> 
        <label for="yes"> Yes</label><br>
        <input type="radio" class="param" name="radio6" ng-model="radio6" value="no" required> 
        <label for="no"> No</label><br>
      </div>
      <p><hr></p>
      """.toString(),
      result: { params->
        a.addEvent("Demographic", ["pid": player.id,
                                   "num_other": params['numeric1'],
                                   "age": params['numeric2'],
                                   "gender": params['radio1'],
                                   "race": params['radio2'],
                                   "education": params['radio3'],
                                   "income": params['radio4'], 
                                   "politics": params['radio5'],
                                   "country": params['radio6']])
        player.text = "<h2>Thank you for participating in this task.</h2>"
        player.text += "<p>Please submit the assignment below.</p>"
        player.text += g.getSubmitForm(player, player.private.bonus)
      }])
                  
    }
    
  } else {
    
    g.V.filter{it.active}.each { player-> 
      
      player.private.bonus = ((player.private.version1_score + player.private.score)/6000).toDouble().round(2)
      if (player.private.bonus < 0) {
        player.private.bonus = 0
      }
      if (player.private.bonus > 1.25) {
        player.private.bonus = 1.25
      }
      player.private.bonus = (2.9 + player.private.bonus).toDouble().round(2)
    
      player.text = c.get("SurveyStep2")

      a.add(player,
      [name: "Submit",
      custom: """
      <p>
         Recall the many choices you had to make whether to 
         <strong>take action A (and contribute points to your neighbors)</strong> 
         or 
         <strong>take action B (and NOT contribute points to your neighbors)</strong> during the game.
      </p>
      <p><strong>
         Which of the following factors were most influential in making you choose action A 
         (and contribute points to your neighbors)? You can check one or more boxes. 
      </strong></p>
      <div>
         <input type="checkbox" class="param" name="checkboxes" ng-model="altruism" value="altruism" 
         ng-required="!encourage && !choseA && !choseB && !equal && !more && !less && !fair && !notfair && !other">
         <label for="altruism">I wanted other players to increase their scores.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="encourage" value="encourage" 
         ng-required="!altruism && !choseA && !choseB && !equal && !more && !less && !fair && !notfair && !other">
         <label for="encourage">I wanted to encourage other players to choose A too.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="choseA" value="choseA" 
         ng-required="!altruism && !encourage && !choseB && !equal && !more && !less && !fair && !notfair && !other">
         <label for="choseA">Most of my neighbors chose A in the previous round.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="choseB" value="choseB" 
         ng-required="!altruism && !encourage && !choseA && !equal && !more && !less && !fair && !notfair && !other">
         <label for="choseB">Most of my neighbors chose B in the previous round.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="equal" value="equal" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !more && !less && !fair && !notfair && !other">
         <label for="equal">Most of my neighbors had similar scores compared to me.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="more" value="more" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !less && !fair && !notfair && !other">
         <label for="more">Most of my neighbors had higher scores compared to me.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="less" value="less" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !more && !fair && !notfair  && !other">
         <label for="less">Most of my neighbors had lower scores compared to me.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="fair" value="fair" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !more && !less && !notfair && !other">
         <label for="fair">I found the rule of initial score allocation to be fair.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="notfair" value="notfair" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !more && !less && !fair && !other">
         <label for="notfair">I didn't find the rule of initial score allocation to be fair.</label><br>

         <input type="checkbox" class="param" name="checkboxes" ng-model="other" value="other" 
         ng-required="!altruism && !encourage && !choseA && !choseB && !equal && !more && !less && !fair && !notfair">
         <label for="other">Other factor not listed here (type your reason below).</label><br>

         <input ng-if="other" type="text" name="othertext" class="param" ng-model="othertext" required>
      </div>
      <p><hr></p>
      """.toString(),
      result: { params->
        a.addEvent("WhyCoop", ["pid": player.id,
                               "why_coop": params['checkboxes'],
                               "why_coop_other": params['othertext']])
        player.text = c.get("SurveyStep2")}])

      a.add(player,
      [name: "Submit",
      custom: """
      <p>How many other HITs have you participated in that required you to interact with other players like this HIT?</p>
      <div>
        <input type="number" class="param" min="0" max="1000000" name="numeric1" ng-model="numeric1" required>
      </div>
      <p><hr></p>
      <p>How old are you?</p>
      <div>
        <input type="number" class="param" min="0" max="200" name="numeric2" ng-model="numeric2" required>
      </div>
      <p><hr></p>
      <p>What gender do you identify with?</p>
      <div>
        <input type="radio" class="param" name="radio1" ng-model="radio1" value="male" required> 
        <label for="male"> Male</label><br>
        <input type="radio" class="param" name="radio1" ng-model="radio1" value="female" required> 
        <label for="female"> Female</label><br>
        <input type="radio" class="param" name="radio1" ng-model="radio1" value="other" required> 
        <label for="other"> Other</label><br>
      </div>
      <p><hr></p>
      <p>What race/ethnicity do you identify with?</p>
      <div>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="white" required> 
        <label for="white"> White</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="black" required> 
        <label for="black"> Black</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="hispanic" required> 
        <label for="hispanic"> Hispanic</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="asian" required> 
        <label for="asian"> Asian</label><br>
        <input type="radio" class="param" name="radio2" ng-model="radio2" value="other" required> 
        <label for="other"> Other</label><br>
      </div>
      <p><hr></p>
      <p>What is your level of education?</p>
      <div>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="less_than_hs" required> 
        <label for="less_than_hs"> Less than high school diploma</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="hs" required> 
        <label for="hs"> High school diploma or equivalent</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="some_college" required> 
        <label for="some_college"> Some college</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="college_degree" required> 
        <label for="college_degree"> College degree</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="graduate_degree" required> 
        <label for="graduate_degree"> Graduate degree</label><br>
        <input type="radio" class="param" name="radio3" ng-model="radio3" value="other" required> 
        <label for="other"> Other</label><br>
      </div>
      <p><hr></p>
      <p>What is your yearly income in US dollars?</p>
      <div>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="less_than_20k" required> 
        <label for="less_than_20k"> Less than \$20,000</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="20k_to_40k" required> 
        <label for="20k_to_40k"> \$20,000 to \$39,999</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="40k_to_60k" required> 
        <label for="40k_to_60k"> \$40,000 to \$59,999</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="60k_to_80k" required> 
        <label for="60k_to_80k"> \$60,000 to \$79,999</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="80k_to_100k" required> 
        <label for="80k_to_100k"> \$80,000 to \$99,999</label><br>
        <input type="radio" class="param" name="radio4" ng-model="radio4" value="more_than_100k" required> 
        <label for="more_than_100k"> More than \$100,000</label><br>
      </div>
      <p><hr></p>
      <p>Which of the following best describes your political orientation?</p>
      <div>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="very_liberal" required> 
        <label for="very_liberal"> Very liberal</label><br>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="liberal" required> 
        <label for="liberal"> Liberal</label><br>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="middle" required> 
        <label for="middle"> Middle of the road</label><br>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="conservative" required> 
        <label for="conservative"> Conservative</label><br>
        <input type="radio" class="param" name="radio5" ng-model="radio5" value="very_conservative" required> 
        <label for="very_conservative"> Very conservative</label><br>
      </div>
      <p><hr></p>
      <p>Are you located in the U.S.?</p>
      <div>
        <input type="radio" class="param" name="radio6" ng-model="radio6" value="yes" required> 
        <label for="yes"> Yes</label><br>
        <input type="radio" class="param" name="radio6" ng-model="radio6" value="no" required> 
        <label for="no"> No</label><br>
      </div>
      <p><hr></p>
      """.toString(),
      result: { params->
        a.addEvent("Demographic", ["pid": player.id,
                                   "num_other": params['numeric1'],
                                   "age": params['numeric2'],
                                   "gender": params['radio1'],
                                   "race": params['radio2'],
                                   "education": params['radio3'],
                                   "income": params['radio4'], 
                                   "politics": params['radio5'],
                                   "country": params['radio6']])
        player.text = "<h2>Thank you for participating in this task.</h2>"
        player.text += "<p>Please submit the assignment below.</p>"
        player.text += g.getSubmitForm(player, player.private.bonus)
      }])
                  
    }
    
  }
  
}

surveyStepEnd.done = {
  
  println "surveyStepEnd.done"
  
}
