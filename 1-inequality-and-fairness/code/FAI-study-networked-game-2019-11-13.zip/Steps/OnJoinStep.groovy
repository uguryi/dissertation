onJoinStep = stepFactory.createNoUserActionStep()

onJoinStep.run = { playerId->
  
  def player = g.getVertex(playerId)
  
  countP = countP + 1
 
  player.private.score = initScore
  player.private.cooperation = 0
  player.private.words = []
  player.private.old_score = -1
  player.private.new_score = -1
  player.private.original_neighbors = []
  player.private.version1_score = 0
  player.private.screenAnswer = ""
  player.private.coop_eng = ""
  
  player.score = initScore
  player.cooperation = 0
  player.active = true
  
  if (!debugMode1) {
    
    player.text = c.get("Welcome")

    a.add(player, [name: "Next", 
                   result: {player.text = c.get("Screening")}, 
                   event: [name: "Tutorial100", data: ["pid": player.id]]])

    a.add(player,
      [name: "Next",
       custom: """
       <p><strong>Two plus one equals...</strong></p>
       <div>
         <input type="text" name="text" class="param" ng-model="text" required>
       </div>
       <p><hr></p>
       """.toString(),
       result: { params->
         player.private.screenAnswer = params['text']
         a.addEvent("Screening", ["pid": player.id, "screenAnswer": params['text']])
         if (player.private.screenAnswer.trim().equals("3") ||
             player.private.screenAnswer.trim().equals("three") ||
             player.private.screenAnswer.trim().equals("Three") ||
             player.private.screenAnswer.trim().equals("THREE")) {
         	player.text = c.get("Tutorial1-1")
         } else {
         	player.text = "<p><span>You have been dropped due to the incorrect answer you entered.</span></p>"
        	player.text += "<p><strong>Please return this HIT.</strong></p>"
            player.active = false
            a.remove(player.id)
            countP = countP - 1
         }
       },
       event: [name: "Tutorial101", data: ["pid": player.id]]])
    
    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial1-2")},
      event: [name: "Tutorial102", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial1-3")},
      event: [name: "Tutorial103", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial1-4")},
      event: [name: "Tutorial104", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial1-5")},
      event: [name: "Tutorial105", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial1-6")},
      event: [name: "Tutorial106", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial1-7")},
      event: [name: "Tutorial107", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial1-8")},
      event: [name: "Tutorial108", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial1-9")},
      event: [name: "Tutorial109", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("PleaseWait")},
      event: [name: "Tutorial110", data: ["pid": player.id]]])
          
  }
  
}

onJoinStep.done = {
  
}
