recordSurveyStep = stepFactory.createStep()

recordSurveyStep.run = {
  
  println "recordSurveyStep.run"
  
  a.setIdleTime(20)
  
  a.setDropPlayers(true)
  
  if (version1 == 'ee') {
    version_text = """You will start the second game with a score that is the average of 
    				  the scores of all players in the word game. This score could 
                      be lower than, equal to, or higher than your actual score from 
                      the word game depending on how your personal performance 
                      compares to how well the other players did in the task. For 
                      example, even if you performed well in the word game, if 
                      other players did not perform as well as you did, your score 
                      will unfortunately go down. Similarly, even if you performed 
                      poorly in the word game, if other players performed better 
                      than you did on average, then your score will go up."""
  } else if (version1 == 'eu') {
    version_text = """You will start the second game with your score from the word game. 
                      Other players similarly start this game with whatever score 
                      they were able to achieve in the word game. In other words, 
                      those who performed well in the word game start the second 
                      game with a higher score than others who did not perform as 
                      well."""
  } else if (version1 == 're') {
    version_text = """We will disregard your score from the word game. Instead, you will start 
    				  the second game with a score that we randomly assign to you. 
                      All participants in your group are assigned the exact same score."""
  } else {
    version_text = """We will disregard your score from the word game. Instead, you will start 
    				  the second game with a score that we randomly assign to you. 
                      This score could be lower than, equal to, or higher than your 
                      actual score from the word game. In other words, even if you 
                      performed well in the word game, you could unfortunately still 
                      get a score that is much lower. Similarly, even if you performed 
                      poorly in the word game, you could still get a score that is 
                      much higher. It is highly likely that different players will be 
                      assigned different random scores."""
  }
  
  lst_scores = []
  g.V.filter{it.active}.each { player->
    lst_scores += [player.private.score]
  }
  
  mean = lst_scores.sum().intdiv(lst_scores.size())
  if (mean > 0 & mean < 100) {
    mean = 50
  } else if (mean >= 100 & mean < 2000) {
    mean = Math.floor(mean / 100).toInteger() * 100
  } else if (mean >= 2000) {
    mean = 2000
  }
  mean_ee = mean

  if (version1 == 'ee') {
    
    g.V.filter{it.active}.each { player->
      a.addEvent("Words",["pid": player.id,
                          "words": player.private.words,
                          "score1": player.private.score])
    }
    g.V.filter{it.active}.each { player->
      player.private.old_score = player.private.score
      player.private.score = mean
      player.score = mean
      player.private.new_score = player.private.score
    }
    
  } else if (version1 == 'eu') {
      
    g.V.filter{it.active}.each { player->
      a.addEvent("Words",["pid":player.id,
                          "words":player.private.words,
                          "score1":player.private.score])
      player.private.old_score = player.private.score
      player.private.new_score = player.private.score

    }
    
  } else if (version1 == 're') {
    
    lst_scores = []
    g.V.filter{it.active}.each { player->
      a.addEvent("Words",["pid":player.id,
                          "words":player.private.words,
                          "score1":player.private.score])
      lst_scores += [player.private.score]
    }
    Collections.shuffle(lst_scores)
    equal = lst_scores[0]
    g.V.filter{it.active}.each { player->
      player.private.old_score = player.private.score
      player.private.score = equal
      player.score = equal
      player.private.new_score = player.private.score
    }
    
  } else {
      
    lst_scores = []
    g.V.filter{it.active}.each { player->
      a.addEvent("Words",["pid":player.id,
                          "words":player.private.words,
                          "score1":player.private.score])
      lst_scores += [player.private.score]
    }
    def idx = 0
    g.V.filter{it.active}.shuffle.each { player->
      player.private.old_score = player.private.score
      player.private.score = lst_scores[idx]
      player.score = lst_scores[idx]
      idx += 1
      player.private.new_score = player.private.score
    }
      
  }
  
  g.V.filter{it.active}.each { player-> 

    player.text = c.get("Tutorial2-1", version_text, player.private.old_score, player.private.new_score)
    
    a.add(player,
      [name: "Submit",
      custom: """
      <p>Please tell us how fair or unfair you find this rule for allocating scores.</p>
      <p><strong>Unfair</strong></p>
      <div>
        <input type="radio" class="param" name="radio" ng-model="radio" value="1" required> 
        <label for="1"> 1</label><br>
        <input type="radio" class="param" name="radio" ng-model="radio" value="2" required> 
        <label for="2"> 2</label><br>
        <input type="radio" class="param" name="radio" ng-model="radio" value="3" required> 
        <label for="3"> 3</label><br>
        <input type="radio" class="param" name="radio" ng-model="radio" value="4" required> 
        <label for="4"> 4</label><br>
        <input type="radio" class="param" name="radio" ng-model="radio" value="5" required> 
        <label for="5"> 5</label><br>
        <input type="radio" class="param" name="radio" ng-model="radio" value="6" required> 
        <label for="6"> 6</label><br>
        <input type="radio" class="param" name="radio" ng-model="radio" value="7" required> 
        <label for="7"> 7</label><br>
      </div>
      <p><strong>Fair</strong></p>
      <p><hr></p>
      """.toString(),
      result: { params->
        a.addEvent("FairScore2", ["pid": player.id,
                                  "f_score2": params['radio']])
        a.addEvent("Tutorial200", ["pid": player.id])
        player.text = c.get("Tutorial2-2")
      }])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial2-3", coc, po)},
      event: [name: "Tutorial201", data: ["pid": player.id]]])
    
    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial2-4")},
      event: [name: "Tutorial202", data: ["pid": player.id]]])
    
    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial2-5")},
      event: [name: "Tutorial203", data: ["pid": player.id]]])
    
    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial2-6")},
      event: [name: "Tutorial204", data: ["pid": player.id]]])
    
    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial2-7")},
      event: [name: "Tutorial205", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial2-8")},
      event: [name: "Tutorial206", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial2-9")},
      event: [name: "Tutorial207", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("Tutorial2-10")},
      event: [name: "Tutorial208", data: ["pid": player.id]]])

    a.add(player, [name: "Next", result: {
      player.text = c.get("PleaseWait")},
      event: [name: "Tutorial209", data: ["pid": player.id]]])

  }
  
}

recordSurveyStep.done = {
  
	println "recordSurveyStep.done"
    curRound = 0
    surveyToCoopStep.start()
  
}
