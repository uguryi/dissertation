cooperationStep = stepFactory.createStep()

cooperationStep.run = {
  
  println "cooperationStep.run: ${curRound}"
  
  a.setIdleTime(12)
  
  g.V.filter{it.active}.each { player->
    
    player.text = c.get("CooperationStep", coc, po)
    
    a.add(player,
          [name: "A", result: {
            player.private.cooperation = 1
            player.neighbors.each { n->
              player.private.score -= coc
            }
            player.text += "<p>Please wait for the other players to make their choices.</p>"
            player.text += "<p>While waiting, please stay on this page as you may be dropped for being idle if you don't make your next move within <strong>20 seconds</strong> when it appears.</p>"}
          ],
          [name: "B", result: {
            player.private.cooperation = -1
            player.text += "<p>Please wait for the other players to make their choices.</p>"
            player.text += "<p>While waiting, please stay on this page as you may be dropped for being idle if you don't make your next move within <strong>20 seconds</strong> when it appears.</p>"}
          ])
  }
}

cooperationStep.done = {
  
  println "cooperationStep.done: ${curRound}"
  recordCoopStep.start()
  
}
