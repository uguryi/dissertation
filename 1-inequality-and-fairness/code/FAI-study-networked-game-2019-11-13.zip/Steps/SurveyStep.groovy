surveyStep = stepFactory.createStep()

surveyStep.run = {
  
	println "surveyStep.run"
  
  	a.setDropPlayers(false)
  
  	def gameStartTimer = new Timer()
  
  	use(TimerMethods) {
    	gameStartTimer.runAfter(60000) {
          g.V.each { player->
            a.remove(player)
          }
          if (curRound == 0) {
            curRound++
            readInWordsStep.start()
          } else {
            recordSurveyStep.start()
          }
    	}
    }
  
    g.V.filter{it.active}.each { player->
      g.addTimer("player": player, time: 60, timerText: "This survey will end in: ")
      player.text = c.get("SurveyStep")
      indices.each { i ->
        text = """
          <p><strong>${lst_of_captchas[i]}</strong></p>
          <div>
            <input type="text" id="${lst_of_answers[i]}" name="${lst_of_answers[i]}" 
            class="word-input param" ng-model="${lst_of_answers[i]}">
          </div>
          <script>document.getElementById("${lst_of_answers[i]}").focus();</script>
          <p><hr></p>"""
      	a.add(player, [name: "Submit", custom: text.toString(), 
                       result: { params->
                         def word = params[lst_of_answers[i].toString()]
                         player.private.words += word
                         if (word.trim().equals(lst_of_answers[i].trim())) {
                           player.private.score += 100
                           player.score += 100
                         } 
                       }
                      ])
      }
    }
}

surveyStep.done = {
  
  println "surveyStep.done"
    
}
