surveyToCoopStep = stepFactory.createStep()

surveyToCoopStep.run = {
  
  println "surveyToCoopStep.run"
  
  a.setIdleTime(20)
  
  if (metaCount == 0) {
    
    if (curRound == 0) {
      g.V.filter{it.active}.each { player->
        player.text = c.get("PleaseWait") + "<p><strong>Click 'Begin Demo Run' to join the demo run.</strong></p>"
        a.add(player, [name: "Begin Demo Run", result: {
          player.text = c.get("PleaseWait") + "<p><strong>Thank you, the demo run will begin in a moment.</strong></p>"
        }])
      }
    } else {
      g.V.filter{it.active}.each { player->
        player.text = c.get("RealSecondGame") + "<p><strong>Click 'Begin' to join the game.</strong></p>"
        a.add(player, [name: "Begin", result: {
          player.text = c.get("RealSecondGame") + "<p><strong>Thank you, the game will begin in a moment.</strong></p>"
        }])
      }  
    }
  
  } else {
    
    //nRounds = nRounds - 2
    
    g.V.filter{it.active}.each { player->
      player.private.cooperation = 0
  	  player.cooperation = 0
    }
    
    if (version2 == 'ee') {
      a.addEvent("GameParameters2", ["earned2": 1, "equal2": 1])
    } else if (version2 == 'eu') {
      a.addEvent("GameParameters2", ["earned2": 1, "equal2": 0])
    } else if (version2 == 're') {
      a.addEvent("GameParameters2", ["earned2": 0, "equal2": 1])
    } else {
      a.addEvent("GameParameters2", ["earned2": 0, "equal2": 0])
    }
    
    g.random(p)
    
    g.V.each { player->
      if (player.active == false) {
      	player.getEdges(Direction.BOTH).each { g.removeEdge(it) }
      }
    }
    
    if (version2 == 'ee') {
      version_text = """You will start the third game with a score that is the average of 
                        the scores of all players in the word game. This score could 
                        be lower than, equal to, or higher than your actual score from 
                        the word game depending on how your personal performance 
                        compares to how well the other players did in the task. For 
                        example, even if you performed well in the word game, if 
                        other players did not perform as well as you did, your score 
                        will unfortunately go down. Similarly, even if you performed 
                        poorly in the word game, if other players performed better 
                        than you did on average, then your score will go up."""
    } else if (version2 == 'eu') {
      version_text = """You will start the third game with your score from the word game. 
                        Other players similarly start this game with whatever score 
                        they were able to achieve in the word game. In other words, 
                        those who performed well in the word game start the third 
                        game with a higher score than others who did not perform as 
                        well."""
    } else if (version2 == 're') {
      version_text = """We will disregard your score from the word game. Instead, you will start 
                        the third game with a score that we randomly assign to you. 
                        All participants in your group are assigned the exact same score."""
    } else {
      version_text = """We will disregard your score from the word game. Instead, you will start 
                        the third game with a score that we randomly assign to you. 
                        This score could be lower than, equal to, or higher than your 
                        actual score from the word game. In other words, even if you 
                        performed well in the word game, you could unfortunately still 
                        get a score that is much lower. Similarly, even if you performed 
                        poorly in the word game, you could still get a score that is 
                        much higher. It is highly likely that different players will be 
                        assigned different random scores."""
    }

    if (version2 == 'ee') {
	  
      g.V.filter{it.active}.each { player->
        player.private.version1_score = player.private.score
      }
      g.V.filter{it.active}.each { player->
        player.private.score = mean_ee
        player.score = mean_ee
        player.private.new_score = player.private.score
      }

    } else if (version2 == 'eu') {

      g.V.filter{it.active}.each { player->
        player.private.version1_score = player.private.score
        player.private.score = player.private.old_score
        player.score = player.private.old_score
        player.private.new_score = player.private.score
      }

    } else if (version2 == 're') {

      lst_scores = []
      g.V.filter{it.active}.each { player->
        lst_scores += [player.private.old_score]
      }
      Collections.shuffle(lst_scores)
      equal = lst_scores[0]
      g.V.filter{it.active}.each { player->
        player.private.version1_score = player.private.score
        player.private.score = equal
        player.score = equal
        player.private.new_score = player.private.score
      }

    } else {

      lst_scores = []
      g.V.filter{it.active}.each { player->
        player.private.version1_score = player.private.score
        lst_scores += [player.private.old_score]
      }
      def idx = 0
      g.V.filter{it.active}.shuffle.each { player->
        player.private.score = lst_scores[idx]
        player.score = lst_scores[idx]
        idx += 1
        player.private.new_score = player.private.score
      }

    }

    g.V.filter{it.active}.each { player-> 

      player.text = c.get("Tutorial3-1")
      
      if (version1 == version2) {
        a.add(player, [name: "Next", 
                       result: {player.text = c.get("Tutorial3-2-Same")},
                       event: [name: "Tutorial300", data: ["pid": player.id]]])
      } else {
        a.add(player, [name: "Next", 
                       result: {player.text = c.get("Tutorial3-2")},
                       event: [name: "Tutorial301", data: ["pid": player.id]]])     
      }

      a.add(player, [name: "Next", 
                     result: {player.text = c.get("Tutorial3-3", 
                                                  version_text, 
                                                  player.private.old_score, 
                                                  player.private.new_score)},
                     event: [name: "Tutorial302", data: ["pid": player.id]]])
      
      a.add(player,
        [name: "Submit",
        custom: """
        <p>Please tell us how fair or unfair you find this rule for allocating scores.</p>
        <p><strong>Unfair</strong></p>
        <div>
          <input type="radio" class="param" name="radio" ng-model="radio" value="1" required> 
          <label for="1"> 1</label><br>
          <input type="radio" class="param" name="radio" ng-model="radio" value="2" required> 
          <label for="2"> 2</label><br>
          <input type="radio" class="param" name="radio" ng-model="radio" value="3" required> 
          <label for="3"> 3</label><br>
          <input type="radio" class="param" name="radio" ng-model="radio" value="4" required> 
          <label for="4"> 4</label><br>
          <input type="radio" class="param" name="radio" ng-model="radio" value="5" required> 
          <label for="5"> 5</label><br>
          <input type="radio" class="param" name="radio" ng-model="radio" value="6" required> 
          <label for="6"> 6</label><br>
          <input type="radio" class="param" name="radio" ng-model="radio" value="7" required> 
          <label for="7"> 7</label><br>
        </div>
        <p><strong>Fair</strong></p>
        <p><hr></p>
        """.toString(),
        result: { params->
          a.addEvent("FairScore3", ["pid": player.id,
                                    "f_score3": params['radio']])
          a.addEvent("Tutorial303", ["pid": player.id])
          player.text = c.get("Tutorial3-4")
        }])

      a.add(player, [name: "Begin", 
                     result: {player.text = c.get("Tutorial3-4") + "<p><strong>Thank you, the game will begin in a moment.</strong></p>"},
                     event: [name: "Tutorial304", data: ["pid": player.id]]])
    
    }
  
  }
  
}

surveyToCoopStep.done = {
  
  println "surveyToCoopStep.done"
  cooperationStep.start()
  
}
