resultsStep = stepFactory.createStep()

resultsStep.run = {
  
  println "resultsStep.run"
  
  g.V.filter{it.active}.each { player->
    player.cooperation = player.private.cooperation
  }
  
  g.V.filter{it.active}.each { player->    
    if (player.cooperation == 1) {
      player.neighbors.each { n->
        n.private.score += po    
        n.score += po 
        player.score -= coc
      }
    }
    
    def fill0 = (player.cooperation == 1) ? "'A'" : "'B'"
    def fill1 = (player.cooperation == 1) ? coc : "0"
    def fill2 = player.neighbors.filter{ it.cooperation == 1 }.count()
    def fill3 = po
    def fill4 = player.neighbors.filter{ it.cooperation == -1 }.count()
    
    player.text = c.get("ResultsStep", fill0, fill1, fill2, fill3, fill4)
    
    a.add(player, [name: "Next", result: {
      player.text += "<p>Please wait for the other players to click 'Next'.</p>"
      player.text += "<p>While waiting, please stay on this page as you may be dropped for being idle if you don't make your next move within <strong>20 seconds</strong> when it appears.</p>"
    }])
    
  }
}

resultsStep.done = {
    
  println "resultsStep.done"
  
  if (secondGameDemoCounter < 2) {
    
    secondGameDemoCounter++
    rewiringStep.start()
    
  } else if (secondGameDemoCounter == 2) {
  
    secondGameDemoCounter++
    curRound++
    g.removeEdges()
    g.V.filter{it.active}.each { player->
      player.private.score = player.private.new_score
      player.score = player.private.new_score
  	  player.private.cooperation = 0
  	  player.cooperation = 0
      if (player.private.original_neighbors != []) {
        player.private.original_neighbors.each { n->
          if (g.getEdge(player, n) == null && n.active == true) {
            g.addEdge(player, n, "connected")
          }
        }
      }
    }
    surveyToCoopStep.start()
  
  } else {
    
    if (curRound < nRounds) {
      curRound++
      rewiringStep.start()
    } else {
      if (metaCount == 0) {
        g.V.filter{it.active}.each { player->
          player.text = c.get("Finished", player.private.score)
        }
      } else {
        g.V.filter{it.active}.each { player->
          player.text = c.get("Finished-ThirdGame", player.private.score)
        }
      }
      surveyStep2.start()
    }
    
  }

}
