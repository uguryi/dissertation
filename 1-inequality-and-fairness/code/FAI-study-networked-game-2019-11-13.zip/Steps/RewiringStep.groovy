rewiringStep = stepFactory.createStep()

rewiringStep.run = {
  
  println "rewiringStep.run"
  
  lst_of_vertices = []
  g.V.filter{it.active}.shuffle.each{ v-> 
    lst_of_vertices += [v]
    v.text = c.get("RewiringStep")
  }

  pairs_of_vertices = []
  lst_of_vertices.each{v1->
    lst_of_vertices.each{v2->
      if (v1 != v2) {
        if (pairs_of_vertices.contains([v2,v1]) == false) {
          pairs_of_vertices += [[v1,v2]]
        }
      }
    }
  }
  
  Collections.shuffle(pairs_of_vertices) 
  
  p_of_v_one_third = []
  if (curRound != 0) {
    if (pairs_of_vertices.size() >= rewiringDenom) {
      (0..pairs_of_vertices.size().intdiv(rewiringDenom)-1).each{
        p_of_v_one_third += [pairs_of_vertices[it]]
      }
    } else {
      p_of_v_one_third = []
    }
  } else {
    if (pairs_of_vertices.size() >= rewiringDenom) {
      (0..pairs_of_vertices.size().intdiv(rewiringDenom)-1).each{
        p_of_v_one_third += [pairs_of_vertices[it]]
      }
    } else {
      p_of_v_one_third = []
    }
  }
  
  p_of_v_one_third.each{p->
    
    def edge = g.getEdge(p[0], p[1])
    
    if (p[0].private.cooperation == 1) {
      p[0].private.coop_eng = "chose 'A'"
    } else if (p[0].private.cooperation == -1) {
      p[0].private.coop_eng = "chose 'B'"
    }
    
    if (p[1].private.cooperation == 1) {
      p[1].private.coop_eng = "chose 'A'"
    } else if (p[1].private.cooperation == -1) {
      p[1].private.coop_eng = "chose 'B'"
    }
    
    if (edge == null) {
      
      g.addEdge(p[0], p[1], "connected")
      
      edge = g.getEdge(p[0], p[1])
      
      edge.private(p[0], ["breaking":"0"])
      edge.private(p[1], ["breaking":"0"])
      
      edge.private(p[0], ["making":"1"])
      edge.private(p[1], ["making":"1"])
     
      def addNone0 = [
        name: "Don't add",
        result: {
          a.addEvent("AddChoice", ["pid":p[0].id,
           			               "round":curRound,
                                   "addChoice":0,
           				           "coopChoiceEgo":p[0].private.cooperation,
                                   "coopChoiceAlter":p[1].private.cooperation,
           				           "scoreEgo":p[0].private.score,
                                   "scoreAlter":p[1].private.score,
                                   "version":metaCount+1])
          edge.p0_add_choice = "-1"
        }
      ]
      
      def addNone1 = [
        name: "Don't add",
        result: {
          a.addEvent("AddChoice", ["pid":p[1].id,
           			               "round":curRound,
                                   "addChoice":0,
           				           "coopChoiceEgo":p[1].private.cooperation,
                                   "coopChoiceAlter":p[0].private.cooperation,
           				           "scoreEgo":p[1].private.score,
                                   "scoreAlter":p[0].private.score,
                                   "version":metaCount+1])
          edge.p1_add_choice = "-1"
        }
      ]
      
      def addTieChoice1 = [
        name: "Add tie with " + p[0].id,
        result: {
          a.addEvent("AddChoice", ["pid":p[1].id,
           			               "round":curRound,
                                   "addChoice":1,
           				           "coopChoiceEgo":p[1].private.cooperation,
                                   "coopChoiceAlter":p[0].private.cooperation,
           				           "scoreEgo":p[1].private.score,
                                   "scoreAlter":p[0].private.score,
                                   "version":metaCount+1])
          edge.p1_add_choice = "1"
        }
      ]

      def addTieChoice0 = [
        name: "Add tie with " + p[1].id,
        result: {
          a.addEvent("AddChoice", ["pid":p[0].id,
           			               "round":curRound,
                                   "addChoice":1,
           				           "coopChoiceEgo":p[0].private.cooperation,
                                   "coopChoiceAlter":p[1].private.cooperation,
           				           "scoreEgo":p[0].private.score,
                                   "scoreAlter":p[1].private.score,
                                   "version":metaCount+1])
          edge.p0_add_choice = "1"
        }
      ]
      
      a.add(p[0], 
            { p[0].text += c.get("RewiringStep-Add", p[1].id, p[1].score, p[1].private.coop_eng) },
            addTieChoice0, 
            addNone0)
      
      a.add(p[1],
            { p[1].text += c.get("RewiringStep-Add", p[0].id, p[0].score, p[0].private.coop_eng) },
            addTieChoice1, 
            addNone1)
      
    } else {
      
      edge.private(p[1], ["breaking":"0"])
      edge.private(p[0], ["making":"0"])
      edge.private(p[1], ["making":"0"])
      edge.private(p[0], ["breaking":"1"])
      
      def cutNone = [
        name: "Don't cut",
        result: { 
          a.addEvent("CutChoice", ["pid":p[0].id,
           			               "round":curRound,
                                   "cutChoice":0,
           				           "coopChoiceEgo":p[0].private.cooperation,
                                   "coopChoiceAlter":p[1].private.cooperation,
           				           "scoreEgo":p[0].private.score,
                                   "scoreAlter":p[1].private.score,
                                   "version":metaCount+1])
          edge.p0_cut_choice = "-1"
        }
      ]
      
      def cutTieChoice = [
        name: "Cut ties with " + p[1].id,
        result: {
          a.addEvent("CutChoice", ["pid":p[0].id,
           			               "round":curRound,
                                   "cutChoice":1,
           				           "coopChoiceEgo":p[0].private.cooperation,
                                   "coopChoiceAlter":p[1].private.cooperation,
           				           "scoreEgo":p[0].private.score,
                                   "scoreAlter":p[1].private.score,
                                   "version":metaCount+1])
          edge.p0_cut_choice = "1"
        }
      ] 
      
      a.add(p[0],
            { p[0].text += c.get("RewiringStep-Cut", p[1].id, p[1].score, p[1].private.coop_eng) },
            cutTieChoice, 
            cutNone)
      
    }
    
  }
  
}

rewiringStep.done = {
  
  println "rewiringStep.done"
  
  g.E.each{e->
    if (e.p0_cut_choice == "1") {
      e.p0_cut_choice = "0"
      g.removeEdge(e)
    } else if (e.p0_add_choice == "1" && e.p1_add_choice == "1") {
      e.p0_add_choice = "0"
      e.p1_add_choice = "0"
    } else if (e.p0_add_choice == "-1" || e.p1_add_choice == "-1") {
      e.p0_add_choice = "0"
      e.p1_add_choice = "0"
      g.removeEdge(e)      
    }
  }
    
  g.E.each{e->
    e.p0_add_choice = "0"
    e.p1_add_choice = "0"
    e.p0_cut_choice = "0"
    e.private(e.getVertex(Direction.IN), ["making":"0"])
    e.private(e.getVertex(Direction.OUT), ["making":"0"])
    e.private(e.getVertex(Direction.IN), ["breaking":"0"])
    e.private(e.getVertex(Direction.OUT), ["breaking":"0"])
  }
    
  cooperationStep.start()
  
}
